import { test, expect } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { readCSV, resolveData } from '../../data/utils';
import { config } from '../../config/testConfig';

const dataRows = readCSV('./tests/login/loginData.csv');

dataRows.forEach((row) => {
  test(`@smoke Login Test - ${row.$username}`, async ({ page }) => {
    const login = new LoginPage(page);
    await page.goto(config.baseURL);

    await login.login(
      resolveData('$username', row),
      resolveData('$password', row)
    );

    await expect(page.locator('h1')).toHaveText('Dashboard');
  });
});
import fs from 'fs';
import path from 'path';
import csvParse from 'csv-parse/sync';

export function readCSV(filepath: string): Record<string, string>[] {
  const content = fs.readFileSync(filepath, 'utf-8');
  return csvParse.parse(content, {
    columns: true,
    skip_empty_lines: true,
  });
}

export function resolveData(input: string, csvRow: Record<string, string>): string {
  return input.startsWith('$') ? csvRow[input.slice(1)] || '' : input;
}
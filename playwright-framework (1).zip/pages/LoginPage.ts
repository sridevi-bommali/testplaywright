import { Page } from '@playwright/test';

export class LoginPage {
  constructor(private page: Page) {}

  usernameField = this.page.locator('#username');
  passwordField = this.page.locator('#password');
  loginButton = this.page.locator('#login');

  async login(username: string, password: string) {
    await this.usernameField.fill(username);
    await this.passwordField.fill(password);
    await this.loginButton.click();
  }
}